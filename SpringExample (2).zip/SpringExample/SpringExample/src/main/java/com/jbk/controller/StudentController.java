package com.jbk.controller;





import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jbk.entity.Student;
import com.jbk.service.StudentService;

@RestController
public class StudentController {

	@Autowired
	SessionFactory sessionFactory;
	
	@Autowired
	StudentService studentService;
	
	@GetMapping("/getStudent/{id}")
	Student getStudent(@PathVariable int id) {
		return studentService.getStudentService(id);
	}

	@GetMapping("/getStudents")
	List<Student> getStudents() {
		
		return studentService.getStudentsService();
	}

	@PostMapping("/addStudent")
	String addStudent() {
		Session session = sessionFactory.openSession();
		Student student = new Student(10, "aaa", 30);
		session.save(student);
		session.beginTransaction().commit();
		return "Student added";
	}
}
