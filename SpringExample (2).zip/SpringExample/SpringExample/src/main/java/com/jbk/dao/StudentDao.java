package com.jbk.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jbk.entity.Student;


@Repository
public class StudentDao {
	
	@Autowired
	SessionFactory sessionFactory;
	
	public Student getStudentDao(int id) {
		Session session = sessionFactory.openSession();
		Student student = session.get(Student.class, id);
		
		return student;
	}
	
	public List<Student> getStudentsDao(){
		Session session = sessionFactory.openSession();
		
		Criteria criteria = session.createCriteria(Student.class);
		List<Student> students = criteria.list();
		return students;
	}

}
